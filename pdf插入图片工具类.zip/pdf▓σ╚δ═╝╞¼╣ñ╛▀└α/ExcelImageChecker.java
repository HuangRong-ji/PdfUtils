package com;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

public class ExcelImageChecker {

    public static void main(String[] args) throws Exception {

        File file = new File("example.xlsx");

        if (!file.exists() || !file.isFile()) {
            System.out.println("Invalid file path provided.");
            return;
        }

        try (InputStream inputStream = new FileInputStream(file)) {
            boolean hasImage = containsImage(inputStream,"image\\");
            System.out.println("Excel file contains image: " + hasImage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @Description: 获取excel文件里面的图片
     * @param inputStream excel文件流
     * @param outPutFilePath 图片输出的路径
     * @return: boolean 是否获取到了文件
     */
    private static boolean containsImage(InputStream inputStream, String outPutFilePath) throws Exception{
        Workbook workbook = WorkbookFactory.create(inputStream);

        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            Sheet sheet = workbook.getSheetAt(i);
            Drawing<?> drawing = sheet.getDrawingPatriarch();

            if (drawing != null) {
                List<? extends PictureData> pictures = workbook.getAllPictures();
                PictureData pictureData = pictures.get(0);
                //  后缀
                String ext = pictureData.suggestFileExtension();
                //  图片数据
                byte[] data = pictureData.getData();
                File dir = new File(outPutFilePath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File imgFile = new File(dir, "image_" + System.currentTimeMillis() + "." + ext);
                try (FileOutputStream out = new FileOutputStream(imgFile)) {
                    out.write(data);
                }
                if (!pictures.isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

}