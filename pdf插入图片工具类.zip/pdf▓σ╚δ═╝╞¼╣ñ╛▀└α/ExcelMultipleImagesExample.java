package com;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelMultipleImagesExample {

    public static void main(String[] args) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Images");

        // Insert multiple images at different positions
        insertImage(sheet, "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\main\\resources\\Snipaste_2024-06-13_17-06-06.png", 0, 0); // Example: insert at cell A1
        insertImage(sheet, "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\main\\resources\\Snipaste_2024-06-13_17-06-06.png", 1, 2); // Example: insert at cell C3

        // Save workbook to file
        try (FileOutputStream fos = new FileOutputStream("output.xlsx")) {
            workbook.write(fos);
        }
        workbook.close();
    }

    private static void insertImage(Sheet sheet, String imagePath, int row, int col) throws IOException {
        Drawing<?> drawing = sheet.createDrawingPatriarch();
        ClientAnchor anchor = sheet.getWorkbook().getCreationHelper().createClientAnchor();
        anchor.setCol1(col); // Starting column
        anchor.setRow1(row); // Starting row
        anchor.setCol2(col + 1); // Ending column
        anchor.setRow2(row + 1); // Ending row

        // Load image
        int pictureIndex = sheet.getWorkbook().addPicture(IOUtils.toByteArray(new FileInputStream(imagePath)),
                Workbook.PICTURE_TYPE_JPEG);
        // Create picture
        Picture picture = drawing.createPicture(anchor, pictureIndex);

        // Optional: Resize picture to desired size
        picture.resize(1, 1); // 1x1 cells
    }
}