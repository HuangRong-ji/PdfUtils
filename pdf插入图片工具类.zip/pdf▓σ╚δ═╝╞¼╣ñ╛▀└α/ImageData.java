package com;

import com.alibaba.excel.annotation.ExcelProperty;

public class ImageData {
    @ExcelProperty("Name")
    private String name;

    @ExcelProperty("Image")
    private byte[] imageData;

    public ImageData() {
    }

    public ImageData(String s, byte[] imageData) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }
}
