package com;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;

public class ExcelStringFinder {

    public static void main(String[] args) {

        String filePath = "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\工程量清单封面.xlsx";
        String searchString = "招 标 人";

        File file = new File(filePath);

        if (!file.exists() || !file.isFile()) {
            System.out.println("Invalid file path provided.");
            return;
        }

        try (InputStream inputStream = new FileInputStream(file)) {
            findString(inputStream, searchString);
        } catch (IOException | InvalidFormatException e) {
            e.printStackTrace();
        }
    }

    /**
     * @Description: 查找这个文件的位置，在图片后面的一个单元格插入图片
     * @param inputStream excel文件流
     * @param searchString 需要搜索的文字
     * @return: void
     */
    public static void findString(InputStream inputStream, String searchString) throws IOException, InvalidFormatException {
        Workbook workbook = WorkbookFactory.create(inputStream);
        String filePath1 = "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\工程量清单封面.xlsx";
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            Sheet sheet = workbook.getSheetAt(i);
            for (Row row : sheet) {
                for (Cell cell : row) {
                    if (cell.getCellType() == CellType.STRING) {
                        String cellValue = cell.getStringCellValue();
                        if (cellValue != null && cellValue.contains(searchString)) {
                            //  插入图片
                            insertImage(filePath1, "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\main\\resources\\Snipaste_2024-06-13_17-06-06.png", row.getRowNum(), cell.getColumnIndex()+1);  // 替换为你的图片路径
                            System.out.println("Found '" + searchString + "' at sheet " + sheet.getSheetName() + ", row " + row.getRowNum() + ", column " + cell.getColumnIndex());
                        }
                    }
                }
            }
        }
    }

    public static void insertImage(String excelFilePath, String imagePath, int row, int col) {
        try (FileInputStream excelFile = new FileInputStream(excelFilePath);
             Workbook workbook = new XSSFWorkbook(excelFile);
             FileInputStream imageFile = new FileInputStream(imagePath)) {

            byte[] bytes = IOUtils.toByteArray(imageFile);
            int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);

            Sheet sheet = workbook.getSheetAt(0);
            Drawing<?> drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = workbook.getCreationHelper().createClientAnchor();
            anchor.setCol1(col);  // 图片插入位置的列索引
            anchor.setRow1(row);  // 图片插入位置的行索引
            anchor.setCol2(col + 1);  // 图片结束列
            anchor.setRow2(row + 1);  // 图片结束行
            drawing.createPicture(anchor, pictureIdx);

            // 重新保存文件
            try (FileOutputStream outFile = new FileOutputStream(excelFilePath)) {
                workbook.write(outFile);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}