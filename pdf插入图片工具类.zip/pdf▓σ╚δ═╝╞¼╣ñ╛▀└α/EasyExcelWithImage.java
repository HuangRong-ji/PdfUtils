package com;

import com.alibaba.excel.EasyExcel;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EasyExcelWithImage {

    // 数据模型类
    public static class UserData {
        private String name;
        private Integer age;
        private String gender;

        public UserData(String name, Integer age, String gender) {
            this.name = name;
            this.age = age;
            this.gender = gender;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }
        // Getters and setters (可以根据需要添加)
        // ...
    }

    public static void main(String[] args) {
        // 准备数据
        List<UserData> dataList = new ArrayList<>();

        // 写入数据到 Excel
        String filePath = "example.xlsx";
        EasyExcel.write(filePath, null).sheet("Sheet1").doWrite(dataList);

        // 插入图片
        insertImage(filePath, "G:\\ideaProject\\湖北省工程造价数据中心\\trunk\\1 源代码\\1.0 系统代码\\前期代码\\AddWatermark\\src\\main\\resources\\Snipaste_2024-06-13_17-06-06.png", 1, 4);  // 替换为你的图片路径
    }

    /**
     * @Description: 插入图片方法
     * @param excelFilePath 文件的路径
     * @param imagePath 图片的路径
     * @param row excel文件的位置 行位置
     * @param col excel文件的位置 列位置
     * @return: void
     */
    public static void insertImage(String excelFilePath, String imagePath, int row, int col) {
        try (FileInputStream excelFile = new FileInputStream(excelFilePath);
             Workbook workbook = new XSSFWorkbook(excelFile);
             FileInputStream imageFile = new FileInputStream(imagePath)) {

            byte[] bytes = IOUtils.toByteArray(imageFile);
            int pictureIdx = workbook.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);

            Sheet sheet = workbook.getSheetAt(0);
            Drawing<?> drawing = sheet.createDrawingPatriarch();
            ClientAnchor anchor = workbook.getCreationHelper().createClientAnchor();
            anchor.setCol1(col);  // 图片插入位置的列索引
            anchor.setRow1(row);  // 图片插入位置的行索引
            anchor.setCol2(col + 2);  // 图片结束列
            anchor.setRow2(row + 2);  // 图片结束行
            drawing.createPicture(anchor, pictureIdx);

            // 重新保存文件
            try (FileOutputStream outFile = new FileOutputStream(excelFilePath)) {
                workbook.write(outFile);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
