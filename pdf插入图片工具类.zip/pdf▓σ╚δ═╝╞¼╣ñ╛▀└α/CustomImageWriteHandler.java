package com;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import org.apache.poi.ss.usermodel.*;

public class CustomImageWriteHandler implements WriteHandler {
    public void afterWorkbookDispose(WriteWorkbookHolder writeWorkbookHolder) {
        Workbook workbook = writeWorkbookHolder.getWorkbook();
        Sheet sheet = workbook.getSheetAt(0);
        Drawing<?> drawing = sheet.createDrawingPatriarch();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            byte[] imageData = (byte[]) sheet.getRow(i).getCell(1).getRichStringCellValue().getString().getBytes();
            if (imageData != null) {
                int pictureIdx = workbook.addPicture(imageData, Workbook.PICTURE_TYPE_PNG);
                ClientAnchor anchor = workbook.getCreationHelper().createClientAnchor();
                anchor.setCol1(1);
                anchor.setRow1(i);
                Picture picture = drawing.createPicture(anchor, pictureIdx);
                picture.resize();
            }
        }
    }
}
