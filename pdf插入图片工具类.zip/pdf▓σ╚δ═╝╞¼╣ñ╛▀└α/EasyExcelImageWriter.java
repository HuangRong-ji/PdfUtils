package com;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.WriteWorkbook;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import org.apache.poi.ss.usermodel.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class EasyExcelImageWriter {
    public static void main(String[] args) throws Exception {
        String fileName = "test.xlsx";

        // 创建示例数据
        List<ImageData> dataList = new ArrayList<>();
        byte[] imageData = downloadImage("https://image.baidu.com/search/detail?ct=503316480&z=0&ipn=d&word=t%E5%9B%BE%E7%89%87&hs=0&pn=0&spn=0&di=7360350738658099201&pi=0&rn=1&tn=baiduimagedetail&is=0%2C0&ie=utf-8&oe=utf-8&cl=2&lm=-1&cs=3247076483%2C2757966786&os=1048851285%2C2802536375&simid=3247076483%2C2757966786&adpicid=0&lpn=0&ln=30&fr=ala&fm=&sme=&cg=&bdtype=0&oriquery=t%E5%9B%BE%E7%89%87&objurl=https%3A%2F%2Fimg95.699pic.com%2Fxsj%2F1b%2F4t%2Flw.jpg!%2Ffw%2F700%2Fwatermark%2Furl%2FL3hzai93YXRlcl9kZXRhaWwyLnBuZw%2Falign%2Fsoutheast&fromurl=ippr_z2C%24qAzdH3FAzdH3Fxf3_z%26e3Bmllrtv_z%26e3Bv54AzdH3Fp7rtwgAzdH3F8k9pso_z%26e3Bip4s&gsm=&islist=&querylist=&dyTabStr=MCwzLDEsMiw0LDYsNSw3LDgsOQ%3D%3D");
        dataList.add(new ImageData("图片测试", imageData));
        CustomImageWriteHandler customImageWriteHandler = new CustomImageWriteHandler();
        customImageWriteHandler.afterWorkbookDispose(new WriteWorkbookHolder(new WriteWorkbook()));
        // 使用 EasyExcel 写入数据和图片
        EasyExcel.write(fileName, ImageData.class)
                .sheet("图片测试")
                .registerWriteHandler(customImageWriteHandler)
                .doWrite(dataList);
    }

    private static byte[] downloadImage(String urlString) throws Exception {
        URL url = new URL(urlString);
        try (InputStream inputStream = url.openStream();
             ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, length);
            }
            return byteArrayOutputStream.toByteArray();
        }
    }
}
